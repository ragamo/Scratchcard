import Game from './game/Game';
import config from './config';

//Create and start the game
new Game(config);