export default {
	profiler: false, //for debug

	width: 800,
	height: 483,

	//PIXI rendererOptions
	options: { 
		backgroundColor : 0x1099bb
		//transparent: true
	}
}